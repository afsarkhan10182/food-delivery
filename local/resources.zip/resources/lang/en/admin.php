<?php

return [

'title' 		=> 'Welcome To Admin Panel',
'userTitle' 	=> 'Login To Continue',

];