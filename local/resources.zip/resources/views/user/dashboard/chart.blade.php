<div class="row">
<div class="col-lg-12  m-b-30">
<div class="card">
<div class="card-header">
<div class="card-title">Last 6 Month Order Report</div>

<div class="card-controls">

<a href="#" class="js-card-refresh icon"> </a>

</div>

</div>
<div class="card-body">
<div id="chart-01"></div>
</div>
<div class="">
</div>
<div class="card-footer">
<div class="d-flex  justify-content-between">
<h6 class="m-b-0 my-auto"><span class="opacity-75"> <i class="mdi mdi-information"></i> Want to view more data</span>
</h6>
<a href="#!" class="btn btn-white shadow-none">Get Full Report</a>
</div>
</div>
</div>
</div>
</div>
